<?php
// support page
// $Id$
//
$title = '服务支持';
include 'header.inc.php';
?>
<div class="block">
	<h2>服务内容</h2>
	<ol>
		<li>SCWS 为本身免费开源的软件包，您无需要支付任何费用即可免费使用它；</li>
		<li>使用中有任何问题或建议，请到我们的<a href="http://bbs.xunsearch.com/forumdisplay.php?fid=8" target="_blank">论坛</a>发帖交流；</li>
		<li>如果您有特殊的词典定制或分词规则需求或其它技术支持需要，欢迎与我联系协商合作方式。</li>
	</ol>	
</div>
<div class="block">
	<h2>联系方式<a name="contact">&nbsp;</a></h2>
	<p>
		<strong>QQ号码：</strong>478161 （验证请注明：SCWS-1.0）<br />
		<strong>电子邮件：</strong>hightman2##yahoo.com.cn（请将 ## 替换成 @）
	</p>	
</div>
<?php include 'footer.inc.php'; ?>